<?php

/**
 * ==========================================================
 * MRM Inventory Management System (MRM-IT-New)
 * Permission Helper
 * File: app/helpers/permission_helper.php
 * ==========================================================
 */

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Get Logged-in User Permissions
|--------------------------------------------------------------------------
*/

function userPermissions(): array
{
    return $_SESSION['permissions'] ?? [];
}

/*
|--------------------------------------------------------------------------
| Check Single Permission
|--------------------------------------------------------------------------
*/

function hasPermission(string $permission): bool
{
    return in_array($permission, userPermissions(), true);
}

/*
|--------------------------------------------------------------------------
| Check Multiple Permissions (ANY)
|--------------------------------------------------------------------------
*/

function hasAnyPermission(array $permissions): bool
{
    foreach ($permissions as $permission) {

        if (hasPermission($permission)) {
            return true;
        }

    }

    return false;
}

/*
|--------------------------------------------------------------------------
| Check Multiple Permissions (ALL)
|--------------------------------------------------------------------------
*/

function hasAllPermissions(array $permissions): bool
{
    foreach ($permissions as $permission) {

        if (!hasPermission($permission)) {
            return false;
        }

    }

    return true;
}

/*
|--------------------------------------------------------------------------
| Require Permission
|--------------------------------------------------------------------------
|
| Redirects the user if permission is missing.
|
*/

function requirePermission(string $permission): void
{
    if (!hasPermission($permission)) {

        $_SESSION['flash'] = [

            'type' => 'danger',

            'message' => 'You do not have permission to access this page.'

        ];

        redirect(APP_URL . '/dashboard/dashboard.php');

        exit;

    }
}

/*
|--------------------------------------------------------------------------
| Require Any Permission
|--------------------------------------------------------------------------
*/

function requireAnyPermission(array $permissions): void
{
    if (!hasAnyPermission($permissions)) {

        $_SESSION['flash'] = [

            'type' => 'danger',

            'message' => 'Access denied.'

        ];

        redirect(APP_URL . '/dashboard/dashboard.php');

        exit;

    }
}

/*
|--------------------------------------------------------------------------
| Require All Permissions
|--------------------------------------------------------------------------
*/

function requireAllPermissions(array $permissions): void
{
    if (!hasAllPermissions($permissions)) {

        $_SESSION['flash'] = [

            'type' => 'danger',

            'message' => 'Access denied.'

        ];

        redirect(APP_URL . '/dashboard/dashboard.php');

        exit;

    }
}

/*
|--------------------------------------------------------------------------
| Check Role
|--------------------------------------------------------------------------
*/

function hasRole(string $role): bool
{
    return ($_SESSION['role_name'] ?? '') === $role;
}

/*
|--------------------------------------------------------------------------
| Check Multiple Roles
|--------------------------------------------------------------------------
*/

function hasAnyRole(array $roles): bool
{
    return in_array(
        $_SESSION['role_name'] ?? '',
        $roles,
        true
    );
}

/*
|--------------------------------------------------------------------------
| Approval Level
|--------------------------------------------------------------------------
*/

function approvalLevel(): int
{
    return (int) ($_SESSION['approval_level'] ?? 0);
}

/*
|--------------------------------------------------------------------------
| Check Approval Level
|--------------------------------------------------------------------------
*/

function hasApprovalLevel(int $level): bool
{
    return approvalLevel() >= $level;
}

/*
|--------------------------------------------------------------------------
| Super Admin Check
|--------------------------------------------------------------------------
*/

function isSuperAdmin(): bool
{
    return hasRole(ROLE_SUPER_ADMIN);
}

/*
|--------------------------------------------------------------------------
| Inventory Admin Check
|--------------------------------------------------------------------------
*/

function isInventoryAdmin(): bool
{
    return hasRole(ROLE_INVENTORY_ADMIN);
}

/*
|--------------------------------------------------------------------------
| Finance Admin Check
|--------------------------------------------------------------------------
*/

function isFinanceAdmin(): bool
{
    return hasRole(ROLE_FINANCE_ADMIN);
}

/*
|--------------------------------------------------------------------------
| Sales Admin Check
|--------------------------------------------------------------------------
*/

function isSalesAdmin(): bool
{
    return hasRole(ROLE_SALES_ADMIN);
}

/*
|--------------------------------------------------------------------------
| Logistics Admin Check
|--------------------------------------------------------------------------
*/

function isLogisticsAdmin(): bool
{
    return hasRole(ROLE_LOGISTICS_ADMIN);
}

/*
|--------------------------------------------------------------------------
| Can Approve Workflow
|--------------------------------------------------------------------------
*/

function canApprove(int $requiredLevel): bool
{
    return approvalLevel() >= $requiredLevel;
}

/*
|--------------------------------------------------------------------------
| Visible Menu Helper
|--------------------------------------------------------------------------
*/

function canViewMenu(array $requiredPermissions): bool
{
    return hasAnyPermission($requiredPermissions);
}

/*
|--------------------------------------------------------------------------
| Button Visibility Helper
|--------------------------------------------------------------------------
*/

function canShowButton(string $permission): bool
{
    return hasPermission($permission);
}