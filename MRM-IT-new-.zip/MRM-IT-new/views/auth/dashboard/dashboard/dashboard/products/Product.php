<?php

/**
 * ==========================================================
 * MRM Inventory Management System (MRM-IT-New)
 * Product Model
 * File: app/models/Product.php
 * ==========================================================
 */

class Product
{
    /**
     * Database connection
     *
     * @var PDO
     */
    private PDO $db;

    /**
     * Table name
     *
     * @var string
     */
    private string $table = 'products';

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /* ==========================================================
     * Get All Products
     * ======================================================== */

    public function all(): array
    {
        $sql = "
            SELECT
                p.*,
                c.category_name,
                s.supplier_name
            FROM products p
            LEFT JOIN categories c
                ON p.category_id = c.category_id
            LEFT JOIN suppliers s
                ON p.supplier_id = s.supplier_id
            ORDER BY p.product_name ASC
        ";

        $stmt = $this->db->query($sql);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Find Product
     * ======================================================== */

    public function find(int $id): ?array
    {
        $sql = "
            SELECT *
            FROM {$this->table}
            WHERE product_id = :id
            LIMIT 1
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            'id' => $id
        ]);

        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        return $product ?: null;
    }

    /* ==========================================================
     * Create Product
     * ======================================================== */

    public function create(array $data): bool
    {
        $sql = "
            INSERT INTO {$this->table}
            (
                product_code,
                product_name,
                category_id,
                supplier_id,
                quantity,
                cost_price,
                selling_price,
                reorder_level,
                status,
                created_at
            )
            VALUES
            (
                :product_code,
                :product_name,
                :category_id,
                :supplier_id,
                :quantity,
                :cost_price,
                :selling_price,
                :reorder_level,
                :status,
                NOW()
            )
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([

            'product_code' => $data['product_code'],

            'product_name' => $data['product_name'],

            'category_id' => $data['category_id'],

            'supplier_id' => $data['supplier_id'],

            'quantity' => $data['quantity'],

            'cost_price' => $data['cost_price'],

            'selling_price' => $data['selling_price'],

            'reorder_level' => $data['reorder_level'],

            'status' => $data['status']

        ]);
    }

    /* ==========================================================
     * Update Product
     * ======================================================== */

    public function update(int $id, array $data): bool
    {
        $sql = "
            UPDATE {$this->table}
            SET

                product_code = :product_code,

                product_name = :product_name,

                category_id = :category_id,

                supplier_id = :supplier_id,

                quantity = :quantity,

                cost_price = :cost_price,

                selling_price = :selling_price,

                reorder_level = :reorder_level,

                status = :status,

                updated_at = NOW()

            WHERE product_id = :id
        ";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([

            'id' => $id,

            'product_code' => $data['product_code'],

            'product_name' => $data['product_name'],

            'category_id' => $data['category_id'],

            'supplier_id' => $data['supplier_id'],

            'quantity' => $data['quantity'],

            'cost_price' => $data['cost_price'],

            'selling_price' => $data['selling_price'],

            'reorder_level' => $data['reorder_level'],

            'status' => $data['status']

        ]);
    }

    /* ==========================================================
     * Delete Product
     * ======================================================== */

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("
            DELETE
            FROM {$this->table}
            WHERE product_id = :id
        ");

        return $stmt->execute([
            'id' => $id
        ]);
    }
}
    /* ==========================================================
     * Search Products
     * ======================================================== */

    public function search(string $keyword): array
    {
        $sql = "
            SELECT
                p.*,
                c.category_name,
                s.supplier_name
            FROM products p
            LEFT JOIN categories c
                ON p.category_id = c.category_id
            LEFT JOIN suppliers s
                ON p.supplier_id = s.supplier_id
            WHERE
                p.product_name LIKE :keyword
                OR p.product_code LIKE :keyword
                OR c.category_name LIKE :keyword
                OR s.supplier_name LIKE :keyword
            ORDER BY p.product_name ASC
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([
            'keyword' => "%{$keyword}%"
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Products by Category
     * ======================================================== */

    public function byCategory(int $categoryId): array
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM products
            WHERE category_id = :category
            ORDER BY product_name
        ");

        $stmt->execute([
            'category' => $categoryId
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Products by Supplier
     * ======================================================== */

    public function bySupplier(int $supplierId): array
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM products
            WHERE supplier_id = :supplier
            ORDER BY product_name
        ");

        $stmt->execute([
            'supplier' => $supplierId
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Active Products
     * ======================================================== */

    public function active(): array
    {
        $stmt = $this->db->query("
            SELECT *
            FROM products
            WHERE status = 'Active'
            ORDER BY product_name
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Low Stock Products
     * ======================================================== */

    public function lowStock(): array
    {
        $stmt = $this->db->query("
            SELECT *
            FROM products
            WHERE quantity <= reorder_level
            ORDER BY quantity ASC
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Out of Stock Products
     * ======================================================== */

    public function outOfStock(): array
    {
        $stmt = $this->db->query("
            SELECT *
            FROM products
            WHERE quantity <= 0
            ORDER BY product_name
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Product Exists by Code
     * ======================================================== */

    public function codeExists(string $code, ?int $excludeId = null): bool
    {
        $sql = "
            SELECT COUNT(*)
            FROM products
            WHERE product_code = :code
        ";

        if ($excludeId !== null) {
            $sql .= " AND product_id <> :exclude_id";
        }

        $stmt = $this->db->prepare($sql);

        $params = [
            'code' => $code
        ];

        if ($excludeId !== null) {
            $params['exclude_id'] = $excludeId;
        }

        $stmt->execute($params);

        return (int)$stmt->fetchColumn() > 0;
    }

    /* ==========================================================
     * Total Products
     * ======================================================== */

    public function count(): int
    {
        return (int)$this->db
            ->query("SELECT COUNT(*) FROM products")
            ->fetchColumn();
    }

    /* ==========================================================
     * Total Low Stock
     * ======================================================== */

    public function countLowStock(): int
    {
        return (int)$this->db
            ->query("
                SELECT COUNT(*)
                FROM products
                WHERE quantity <= reorder_level
            ")
            ->fetchColumn();
    }

    /* ==========================================================
     * Inventory Value
     * ======================================================== */

    public function inventoryValue(): float
    {
        return (float)$this->db
            ->query("
                SELECT
                    SUM(quantity * cost_price)
                FROM products
            ")
            ->fetchColumn();
    }

    /* ==========================================================
     * Latest Products
     * ======================================================== */

    public function latest(int $limit = 10): array
    {
        $limit = (int)$limit;

        $stmt = $this->db->query("
            SELECT *
            FROM products
            ORDER BY created_at DESC
            LIMIT {$limit}
        ");

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
        /* ==========================================================
     * Paginated Products
     * ======================================================== */

    public function paginate(int $page = 1, int $perPage = 20): array
    {
        $page = max(1, $page);
        $offset = ($page - 1) * $perPage;

        $sql = "
            SELECT
                p.*,
                c.category_name,
                s.supplier_name
            FROM products p
            LEFT JOIN categories c
                ON p.category_id = c.category_id
            LEFT JOIN suppliers s
                ON p.supplier_id = s.supplier_id
            ORDER BY p.product_name ASC
            LIMIT :offset, :limit
        ";

        $stmt = $this->db->prepare($sql);

        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* ==========================================================
     * Increase Stock
     * ======================================================== */

    public function increaseStock(int $productId, int $quantity): bool
    {
        $stmt = $this->db->prepare("
            UPDATE products
            SET
                quantity = quantity + :qty,
                updated_at = NOW()
            WHERE product_id = :id
        ");

        return $stmt->execute([
            'qty' => $quantity,
            'id'  => $productId
        ]);
    }

    /* ==========================================================
     * Reduce Stock
     * ======================================================== */

    public function reduceStock(int $productId, int $quantity): bool
    {
        $stmt = $this->db->prepare("
            UPDATE products
            SET
                quantity = GREATEST(quantity - :qty, 0),
                updated_at = NOW()
            WHERE product_id = :id
        ");

        return $stmt->execute([
            'qty' => $quantity,
            'id'  => $productId
        ]);
    }

    /* ==========================================================
     * Set Stock Quantity
     * ======================================================== */

    public function updateStock(int $productId, int $quantity): bool
    {
        $stmt = $this->db->prepare("
            UPDATE products
            SET
                quantity = :qty,
                updated_at = NOW()
            WHERE product_id = :id
        ");

        return $stmt->execute([
            'qty' => $quantity,
            'id'  => $productId
        ]);
    }

    /* ==========================================================
     * Find By Product Code
     * ======================================================== */

    public function findByCode(string $code): ?array
    {
        $stmt = $this->db->prepare("
            SELECT *
            FROM products
            WHERE product_code = :code
            LIMIT 1
        ");

        $stmt->execute([
            'code' => $code
        ]);

        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        return $product ?: null;
    }

    /* ==========================================================
     * Soft Delete
     * ======================================================== */

    public function softDelete(int $id): bool
    {
        $stmt = $this->db->prepare("
            UPDATE products
            SET
                status = 'Deleted',
                updated_at = NOW()
            WHERE product_id = :id
        ");

        return $stmt->execute([
            'id' => $id
        ]);
    }

    /* ==========================================================
     * Restore Product
     * ======================================================== */

    public function restore(int $id): bool
    {
        $stmt = $this->db->prepare("
            UPDATE products
            SET
                status = 'Active',
                updated_at = NOW()
            WHERE product_id = :id
        ");

        return $stmt->execute([
            'id' => $id
        ]);
    }

    /* ==========================================================
     * Bulk Delete
     * ======================================================== */

    public function bulkDelete(array $ids): bool
    {
        if (empty($ids)) {
            return false;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $stmt = $this->db->prepare("
            DELETE
            FROM products
            WHERE product_id IN ($placeholders)
        ");

        return $stmt->execute($ids);
    }

    /* ==========================================================
     * Generate Product Code
     * ======================================================== */

    public function generateProductCode(): string
    {
        $year = date('Y');

        $stmt = $this->db->query("
            SELECT MAX(product_id)
            FROM products
        ");

        $next = ((int)$stmt->fetchColumn()) + 1;

        return sprintf(
            'PRD-%s-%05d',
            $year,
            $next
        );
    }

    /* ==========================================================
     * Product Statistics
     * ======================================================== */

    public function statistics(): array
    {
        return [

            'total_products' => $this->count(),

            'active_products' => count($this->active()),

            'low_stock' => $this->countLowStock(),

            'out_of_stock' => count($this->outOfStock()),

            'inventory_value' => $this->inventoryValue()

        ];
    }

    /* ==========================================================
     * Database Transaction Helpers
     * ======================================================== */

    public function beginTransaction(): bool
    {
        return $this->db->beginTransaction();
    }

    public function commit(): bool
    {
        return $this->db->commit();
    }

    public function rollback(): bool
    {
        return $this->db->rollBack();
    }