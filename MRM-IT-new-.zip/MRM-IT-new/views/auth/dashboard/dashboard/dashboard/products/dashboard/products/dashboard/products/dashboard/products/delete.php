<?php

/**
 * ==========================================================
 * MRM Inventory Management System
 * Delete Product
 * ----------------------------------------------------------
 * File: dashboard/products/delete.php
 * Description:
 * Displays a confirmation page before deleting a product.
 * ==========================================================
 */

require_once '../../app/config/bootstrap.php';

requireLogin();
requirePermission('products.delete');

/*
|--------------------------------------------------------------------------
| Controller
|--------------------------------------------------------------------------
*/

$productController = new ProductController();

/*
|--------------------------------------------------------------------------
| Validate Product ID
|--------------------------------------------------------------------------
*/

$productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$productId) {

    $_SESSION['error'] = 'Invalid product selected.';

    header('Location: index.php');

    exit;

}

/*
|--------------------------------------------------------------------------
| Load Product
|--------------------------------------------------------------------------
*/

$product = $productController->show($productId);

if (!$product) {

    $_SESSION['error'] = 'The requested product could not be found.';

    header('Location: index.php');

    exit;

}

/*
|--------------------------------------------------------------------------
| Delete Product
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($productController->destroy($productId)) {

        $_SESSION['success'] =
            '"' . htmlspecialchars($product['product_name']) .
            '" has been deleted successfully.';

    } else {

        $_SESSION['error'] =
            'Unable to delete the selected product.';

    }

    header('Location: index.php');

    exit;

}

/*
|--------------------------------------------------------------------------
| Page
|--------------------------------------------------------------------------
*/

$pageTitle = 'Delete Product';

include '../partials/header.php';
include '../partials/sidebar.php';
include '../partials/navbar.php';

?>

<div class="container-fluid py-4">

    <!-- ==============================================
         PAGE HEADER
    =============================================== -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold text-danger">

                Delete Product

            </h2>

            <p class="text-muted mb-0">

                Confirm before permanently deleting this product.

            </p>

        </div>

        <a href="index.php"

           class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Back to Products

        </a>

    </div>

    <!-- ==============================================
         CONFIRMATION CARD
    =============================================== -->

    <div class="row justify-content-center">

        <div class="col-lg-7">

            <div class="card shadow border-0">

                <div class="card-header bg-danger text-white">

                    <h4 class="mb-0">

                        Delete Confirmation

                    </h4>

                </div>

                <div class="card-body">

                    <div class="text-center mb-4">

                        <i class="bi bi-exclamation-triangle-fill text-danger"
                           style="font-size:70px;"></i>

                    </div>

                    <div class="alert alert-warning">

                        <strong>Warning:</strong>

                        This action cannot be undone.

                    </div>

                    <table class="table table-bordered">

                        <tr>

                            <th width="35%">

                                Product Code

                            </th>

                            <td>

                                <?= htmlspecialchars($product['product_code']) ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Product Name

                            </th>

                            <td>

                                <?= htmlspecialchars($product['product_name']) ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Category

                            </th>

                            <td>

                                <?= htmlspecialchars($product['category_name'] ?? 'N/A') ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Supplier

                            </th>

                            <td>

                                <?= htmlspecialchars($product['supplier_name'] ?? 'N/A') ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Quantity

                            </th>

                            <td>

                                <?= number_format($product['quantity']) ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Selling Price

                            </th>

                            <td>

                                KSh <?= number_format((float)$product['selling_price'], 2) ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Status

                            </th>

                            <td>

                                <?= htmlspecialchars($product['status']) ?>

                            </td>

                        </tr>

                    </table>

                    <form method="POST">

                        <div class="d-flex justify-content-between mt-4">

                            <a href="index.php"

                               class="btn btn-secondary">

                                <i class="bi bi-x-circle"></i>

                                Cancel

                            </a>

                            <button

                                type="submit"

                                class="btn btn-danger">

                                <i class="bi bi-trash"></i>

                                Delete Product

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include '../partials/footer.php'; ?>