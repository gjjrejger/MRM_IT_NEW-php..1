<?php

/**
 * ==========================================================
 * MRM Inventory Management System
 * Edit Product
 * File: dashboard/products/edit.php
 * ==========================================================
 */

require_once '../../app/config/bootstrap.php';

requireLogin();

requirePermission('products.edit');

$productController = new ProductController();

/*
|--------------------------------------------------------------------------
| Validate Product ID
|--------------------------------------------------------------------------
*/

$id = isset($_GET['id'])

    ? (int) $_GET['id']

    : 0;

if ($id <= 0) {

    $_SESSION['error'] = 'Invalid product selected.';

    header('Location: index.php');

    exit;

}

/*
|--------------------------------------------------------------------------
| Load Product
|--------------------------------------------------------------------------
*/

$product = $productController->show($id);

if (!$product) {

    $_SESSION['error'] = 'Product not found.';

    header('Location: index.php');

    exit;

}

/*
|--------------------------------------------------------------------------
| Temporary Data
|--------------------------------------------------------------------------
|
| These will later come from
| CategoryController
| SupplierController
|
*/

$categories = [];

$suppliers = [];

/*
|--------------------------------------------------------------------------
| Update Product
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($productController->update($id)) {

        header('Location: index.php');

        exit;

    }

}

$pageTitle = 'Edit Product';

include '../partials/header.php';

include '../partials/sidebar.php';

include '../partials/navbar.php';

?>

<div class="container-fluid py-4">

    <!-- ===============================================
         PAGE HEADER
    ================================================ -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                Edit Product

            </h2>

            <p class="text-muted">

                Update product information.

            </p>

        </div>

        <a href="index.php"

           class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Back to Products

        </a>

    </div>

    <!-- ===============================================
         ALERTS
    ================================================ -->

    <?php if (!empty($_SESSION['error'])): ?>

        <div class="alert alert-danger">

            <?= htmlspecialchars($_SESSION['error']) ?>

        </div>

        <?php unset($_SESSION['error']); ?>

    <?php endif; ?>

    <?php if (!empty($_SESSION['success'])): ?>

        <div class="alert alert-success">

            <?= htmlspecialchars($_SESSION['success']) ?>

        </div>

        <?php unset($_SESSION['success']); ?>

    <?php endif; ?>

    <!-- ===============================================
         FORM
    ================================================ -->

    <form

        method="POST"

        enctype="multipart/form-data"

        class="card shadow-sm border-0">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">

                Product Information

            </h5>

        </div>

        <div class="card-body">

            <div class="row">

                <!-- Product Code -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Product Code

                    </label>

                    <input

                        type="text"

                        name="product_code"

                        class="form-control"

                        value="<?= htmlspecialchars($product['product_code']) ?>"

                        readonly>

                </div>

                <!-- Product Name -->

                <div class="col-md-8 mb-3">

                    <label class="form-label">

                        Product Name

                    </label>

                    <input

                        type="text"

                        name="product_name"

                        class="form-control"

                        value="<?= htmlspecialchars($product['product_name']) ?>"

                        required>

                </div>
                                <!-- Category -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Category

                    </label>

                    <select

                        name="category_id"

                        class="form-select"

                        required>

                        <option value="">

                            -- Select Category --

                        </option>

                        <?php if (!empty($categories)): ?>

                            <?php foreach ($categories as $category): ?>

                                <option

                                    value="<?= (int)$category['category_id'] ?>"

                                    <?= $product['category_id'] == $category['category_id']

                                        ? 'selected'

                                        : '' ?>>

                                    <?= htmlspecialchars($category['category_name']) ?>

                                </option>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <option disabled>

                                No categories available

                            </option>

                        <?php endif; ?>

                    </select>

                </div>

                <!-- Supplier -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Supplier

                    </label>

                    <select

                        name="supplier_id"

                        class="form-select"

                        required>

                        <option value="">

                            -- Select Supplier --

                        </option>

                        <?php if (!empty($suppliers)): ?>

                            <?php foreach ($suppliers as $supplier): ?>

                                <option

                                    value="<?= (int)$supplier['supplier_id'] ?>"

                                    <?= $product['supplier_id'] == $supplier['supplier_id']

                                        ? 'selected'

                                        : '' ?>>

                                    <?= htmlspecialchars($supplier['supplier_name']) ?>

                                </option>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <option disabled>

                                No suppliers available

                            </option>

                        <?php endif; ?>

                    </select>

                </div>

                <!-- Status -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Status

                    </label>

                    <select

                        name="status"

                        class="form-select">

                        <option

                            value="Active"

                            <?= $product['status'] === 'Active'

                                ? 'selected'

                                : '' ?>>

                            Active

                        </option>

                        <option

                            value="Inactive"

                            <?= $product['status'] === 'Inactive'

                                ? 'selected'

                                : '' ?>>

                            Inactive

                        </option>

                    </select>

                </div>

                <!-- Quantity -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Quantity

                    </label>

                    <input

                        type="number"

                        name="quantity"

                        class="form-control"

                        min="0"

                        value="<?= (int)$product['quantity'] ?>"

                        required>

                </div>

                <!-- Cost Price -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Cost Price (KSh)

                    </label>

                    <input

                        type="number"

                        name="cost_price"

                        class="form-control"

                        step="0.01"

                        min="0"

                        value="<?= htmlspecialchars($product['cost_price']) ?>"

                        required>

                </div>

                <!-- Selling Price -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Selling Price (KSh)

                    </label>

                    <input

                        type="number"

                        name="selling_price"

                        class="form-control"

                        step="0.01"

                        min="0"

                        value="<?= htmlspecialchars($product['selling_price']) ?>"

                        required>

                </div>

                <!-- Reorder Level -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Reorder Level

                    </label>

                    <input

                        type="number"

                        name="reorder_level"

                        class="form-control"

                        min="0"

                        value="<?= (int)$product['reorder_level'] ?>"

                        required>

                </div>

                <!-- Description -->

                <div class="col-12 mb-3">

                    <label class="form-label">

                        Product Description

                    </label>

                    <textarea

                        name="description"

                        rows="5"

                        class="form-control"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>

                </div>

                <!-- Current Product Image -->

                <div class="col-md-6 mb-3">

                    <label class="form-label">

                        Current Product Image

                    </label>

                    <div>

                        <?php if (!empty($product['image'])): ?>

                            <img

                                src="<?= APP_URL ?>/uploads/products/<?= htmlspecialchars($product['image']) ?>"

                                alt="Product Image"

                                class="img-thumbnail"

                                style="max-width:220px;">

                        <?php else: ?>

                            <div class="border rounded p-4 text-center text-muted">

                                No image uploaded

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

                <!-- Replace Image -->

                <div class="col-md-6 mb-3">

                    <label class="form-label">

                        Replace Product Image

                    </label>

                    <input

                        type="file"

                        name="product_image"

                        class="form-control"

                        accept=".jpg,.jpeg,.png,.webp">

                    <small class="text-muted">

                        Leave blank to keep the current image.

                    </small>

                </div>

            </div>

        </div>
                <!-- ===============================================
             FORM ACTIONS
        ================================================ -->

        <div class="card-footer bg-light">

            <div class="d-flex justify-content-between">

                <a href="index.php"
                   class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>

                    Back

                </a>

                <div>

                    <button
                        type="reset"
                        class="btn btn-warning">

                        <i class="bi bi-arrow-counterclockwise"></i>

                        Reset

                    </button>

                    <button
                        type="submit"
                        class="btn btn-success">

                        <i class="bi bi-check-circle"></i>

                        Update Product

                    </button>

                </div>

            </div>

        </div>

    </form>

</div>

<?php include '../partials/footer.php'; ?>

<script>

document.addEventListener('DOMContentLoaded', function () {

    const costPrice = document.querySelector('input[name="cost_price"]');
    const sellingPrice = document.querySelector('input[name="selling_price"]');
    const imageInput = document.querySelector('input[name="product_image"]');

    /*
    ==========================================================
    Live Profit Margin
    ==========================================================
    */

    function calculateMargin() {

        if (!costPrice || !sellingPrice) return;

        const cost = parseFloat(costPrice.value) || 0;
        const selling = parseFloat(sellingPrice.value) || 0;

        let marginBox = document.getElementById('marginPreview');

        if (cost > 0 && selling > 0) {

            const margin = ((selling - cost) / cost) * 100;

            if (!marginBox) {

                marginBox = document.createElement('div');

                marginBox.id = 'marginPreview';

                marginBox.className = 'alert alert-info mt-2';

                sellingPrice.parentNode.appendChild(marginBox);

            }

            marginBox.innerHTML =
                '<strong>Estimated Profit Margin:</strong> '
                + margin.toFixed(2)
                + '%';

        } else {

            if (marginBox) {

                marginBox.remove();

            }

        }

    }

    if (costPrice) {

        costPrice.addEventListener('input', calculateMargin);

    }

    if (sellingPrice) {

        sellingPrice.addEventListener('input', calculateMargin);

    }

    calculateMargin();

    /*
    ==========================================================
    Image Preview
    ==========================================================
    */

    if (imageInput) {

        imageInput.addEventListener('change', function () {

            if (!this.files.length) return;

            const file = this.files[0];

            if (file.size > 2 * 1024 * 1024) {

                alert('Please choose an image smaller than 2 MB.');

                this.value = '';

                return;

            }

            let preview = document.getElementById('newImagePreview');

            if (!preview) {

                preview = document.createElement('img');

                preview.id = 'newImagePreview';

                preview.className = 'img-thumbnail mt-3';

                preview.style.maxWidth = '220px';

                imageInput.parentNode.appendChild(preview);

            }

            preview.src = URL.createObjectURL(file);

        });

    }

    /*
    ==========================================================
    Selling Price Validation
    ==========================================================
    */

    const form = document.querySelector('form');

    if (form) {

        form.addEventListener('submit', function (e) {

            const cost = parseFloat(costPrice.value) || 0;
            const selling = parseFloat(sellingPrice.value) || 0;

            if (selling < cost) {

                const proceed = confirm(
                    'The selling price is lower than the cost price.\n\nDo you want to continue?'
                );

                if (!proceed) {

                    e.preventDefault();

                }

            }

        });

    }

});

</script>