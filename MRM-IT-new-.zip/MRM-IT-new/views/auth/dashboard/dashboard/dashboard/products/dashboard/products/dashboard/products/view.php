<?php

/**
 * ==========================================================
 * MRM Inventory Management System
 * View Product
 * File: dashboard/products/view.php
 * ==========================================================
 */

require_once '../../app/config/bootstrap.php';

requireLogin();

requirePermission('products.view');

$productController = new ProductController();

/*
|--------------------------------------------------------------------------
| Validate Product ID
|--------------------------------------------------------------------------
*/

$id = isset($_GET['id'])
    ? (int) $_GET['id']
    : 0;

if ($id <= 0) {

    $_SESSION['error'] = 'Invalid product selected.';

    header('Location: index.php');

    exit;

}

/*
|--------------------------------------------------------------------------
| Load Product
|--------------------------------------------------------------------------
*/

$product = $productController->show($id);

if (!$product) {

    $_SESSION['error'] = 'Product not found.';

    header('Location: index.php');

    exit;

}

$pageTitle = 'View Product';

include '../partials/header.php';
include '../partials/sidebar.php';
include '../partials/navbar.php';

$profit = (float)$product['selling_price'] - (float)$product['cost_price'];

$margin = $product['cost_price'] > 0
    ? ($profit / $product['cost_price']) * 100
    : 0;

?>

<div class="container-fluid py-4">

    <!-- ===============================================
         PAGE HEADER
    ================================================ -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                Product Details

            </h2>

            <p class="text-muted">

                Complete information for this product.

            </p>

        </div>

        <div>

            <?php if(hasPermission('products.edit')): ?>

                <a href="edit.php?id=<?= (int)$product['product_id'] ?>"

                   class="btn btn-primary">

                    <i class="bi bi-pencil-square"></i>

                    Edit

                </a>

            <?php endif; ?>

            <a href="index.php"

               class="btn btn-secondary">

                <i class="bi bi-arrow-left"></i>

                Back

            </a>

        </div>

    </div>

    <div class="row">

        <!-- ==========================================
             PRODUCT IMAGE
        =========================================== -->

        <div class="col-lg-4">

            <div class="card shadow-sm border-0 mb-4">

                <div class="card-body text-center">

                    <?php if(!empty($product['image'])): ?>

                        <img

                            src="<?= APP_URL ?>/uploads/products/<?= htmlspecialchars($product['image']) ?>"

                            class="img-fluid rounded"

                            style="max-height:300px;"

                            alt="Product Image">

                    <?php else: ?>

                        <div class="py-5">

                            <i class="bi bi-box display-1 text-secondary"></i>

                            <h5 class="mt-3">

                                No Product Image

                            </h5>

                        </div>

                    <?php endif; ?>

                    <hr>

                    <h4>

                        <?= htmlspecialchars($product['product_name']) ?>

                    </h4>

                    <p class="text-muted">

                        <?= htmlspecialchars($product['product_code']) ?>

                    </p>

                </div>

            </div>

        </div>

        <!-- ==========================================
             PRODUCT INFORMATION
        =========================================== -->

        <div class="col-lg-8">

            <div class="card shadow-sm border-0">

                <div class="card-header">

                    <h5 class="mb-0">

                        Product Information

                    </h5>

                </div>

                <div class="card-body">

                    <div class="row">

                        <div class="col-md-6 mb-3">

                            <strong>Category</strong>

                            <br>

                            <?= htmlspecialchars($product['category_name'] ?? 'N/A') ?>

                        </div>

                        <div class="col-md-6 mb-3">

                            <strong>Supplier</strong>

                            <br>

                            <?= htmlspecialchars($product['supplier_name'] ?? 'N/A') ?>

                        </div>

                        <div class="col-md-6 mb-3">

                            <strong>Status</strong>

                            <br>

                            <?php

                            switch($product['status']){

                                case 'Active':

                                    echo '<span class="badge bg-success">Active</span>';

                                    break;

                                case 'Inactive':

                                    echo '<span class="badge bg-secondary">Inactive</span>';

                                    break;

                                default:

                                    echo '<span class="badge bg-danger">'
                                         . htmlspecialchars($product['status'])
                                         . '</span>';

                            }

                            ?>

                        </div>

                        <div class="col-md-6 mb-3">

                            <strong>Current Stock</strong>

                            <br>

                            <?= number_format($product['quantity']) ?>

                        </div>
                                               <!-- Cost Price -->

                        <div class="col-md-6 mb-3">

                            <strong>Cost Price</strong>

                            <br>

                            <span class="text-danger fw-bold">

                                KSh <?= number_format((float)$product['cost_price'], 2) ?>

                            </span>

                        </div>

                        <!-- Selling Price -->

                        <div class="col-md-6 mb-3">

                            <strong>Selling Price</strong>

                            <br>

                            <span class="text-success fw-bold">

                                KSh <?= number_format((float)$product['selling_price'], 2) ?>

                            </span>

                        </div>

                        <!-- Profit -->

                        <div class="col-md-6 mb-3">

                            <strong>Profit Per Unit</strong>

                            <br>

                            <span class="fw-bold <?= $profit >= 0 ? 'text-success' : 'text-danger' ?>">

                                KSh <?= number_format($profit, 2) ?>

                            </span>

                        </div>

                        <!-- Profit Margin -->

                        <div class="col-md-6 mb-3">

                            <strong>Profit Margin</strong>

                            <br>

                            <span class="badge bg-info fs-6">

                                <?= number_format($margin, 2) ?>%

                            </span>

                        </div>

                        <!-- Reorder Level -->

                        <div class="col-md-6 mb-3">

                            <strong>Reorder Level</strong>

                            <br>

                            <?= number_format($product['reorder_level']) ?>

                        </div>

                        <!-- Stock Status -->

                        <div class="col-md-6 mb-3">

                            <strong>Stock Status</strong>

                            <br>

                            <?php if ($product['quantity'] <= 0): ?>

                                <span class="badge bg-danger">

                                    Out of Stock

                                </span>

                            <?php elseif ($product['quantity'] <= $product['reorder_level']): ?>

                                <span class="badge bg-warning text-dark">

                                    Low Stock

                                </span>

                            <?php else: ?>

                                <span class="badge bg-success">

                                    In Stock

                                </span>

                            <?php endif; ?>

                        </div>

                        <!-- Product Description -->

                        <div class="col-12 mt-4">

                            <h5>

                                Product Description

                            </h5>

                            <hr>

                            <?php if (!empty($product['description'])): ?>

                                <p class="text-muted">

                                    <?= nl2br(htmlspecialchars($product['description'])) ?>

                                </p>

                            <?php else: ?>

                                <p class="text-muted">

                                    No description available.

                                </p>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- ===============================================
         INVENTORY SUMMARY
    ================================================ -->

    <div class="row mt-4">

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-box-seam display-6 text-primary"></i>

                    <h6 class="mt-3">

                        Stock Quantity

                    </h6>

                    <h3>

                        <?= number_format($product['quantity']) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-cash-stack display-6 text-success"></i>

                    <h6 class="mt-3">

                        Inventory Value

                    </h6>

                    <h3>

                        KSh <?= number_format($product['quantity'] * $product['cost_price'], 2) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-graph-up-arrow display-6 text-info"></i>

                    <h6 class="mt-3">

                        Potential Revenue

                    </h6>

                    <h3>

                        KSh <?= number_format($product['quantity'] * $product['selling_price'], 2) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-currency-dollar display-6 text-warning"></i>

                    <h6 class="mt-3">

                        Potential Profit

                    </h6>

                    <h3>

                        KSh <?= number_format($product['quantity'] * $profit, 2) ?>

                    </h3>

                </div>

            </div>

        </div>

    </div> 
                            <!-- Cost Price -->

                        <div class="col-md-6 mb-3">

                            <strong>Cost Price</strong>

                            <br>

                            <span class="text-danger fw-bold">

                                KSh <?= number_format((float)$product['cost_price'], 2) ?>

                            </span>

                        </div>

                        <!-- Selling Price -->

                        <div class="col-md-6 mb-3">

                            <strong>Selling Price</strong>

                            <br>

                            <span class="text-success fw-bold">

                                KSh <?= number_format((float)$product['selling_price'], 2) ?>

                            </span>

                        </div>

                        <!-- Profit -->

                        <div class="col-md-6 mb-3">

                            <strong>Profit Per Unit</strong>

                            <br>

                            <span class="fw-bold <?= $profit >= 0 ? 'text-success' : 'text-danger' ?>">

                                KSh <?= number_format($profit, 2) ?>

                            </span>

                        </div>

                        <!-- Profit Margin -->

                        <div class="col-md-6 mb-3">

                            <strong>Profit Margin</strong>

                            <br>

                            <span class="badge bg-info fs-6">

                                <?= number_format($margin, 2) ?>%

                            </span>

                        </div>

                        <!-- Reorder Level -->

                        <div class="col-md-6 mb-3">

                            <strong>Reorder Level</strong>

                            <br>

                            <?= number_format($product['reorder_level']) ?>

                        </div>

                        <!-- Stock Status -->

                        <div class="col-md-6 mb-3">

                            <strong>Stock Status</strong>

                            <br>

                            <?php if ($product['quantity'] <= 0): ?>

                                <span class="badge bg-danger">

                                    Out of Stock

                                </span>

                            <?php elseif ($product['quantity'] <= $product['reorder_level']): ?>

                                <span class="badge bg-warning text-dark">

                                    Low Stock

                                </span>

                            <?php else: ?>

                                <span class="badge bg-success">

                                    In Stock

                                </span>

                            <?php endif; ?>

                        </div>

                        <!-- Product Description -->

                        <div class="col-12 mt-4">

                            <h5>

                                Product Description

                            </h5>

                            <hr>

                            <?php if (!empty($product['description'])): ?>

                                <p class="text-muted">

                                    <?= nl2br(htmlspecialchars($product['description'])) ?>

                                </p>

                            <?php else: ?>

                                <p class="text-muted">

                                    No description available.

                                </p>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- ===============================================
         INVENTORY SUMMARY
    ================================================ -->

    <div class="row mt-4">

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-box-seam display-6 text-primary"></i>

                    <h6 class="mt-3">

                        Stock Quantity

                    </h6>

                    <h3>

                        <?= number_format($product['quantity']) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-cash-stack display-6 text-success"></i>

                    <h6 class="mt-3">

                        Inventory Value

                    </h6>

                    <h3>

                        KSh <?= number_format($product['quantity'] * $product['cost_price'], 2) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-graph-up-arrow display-6 text-info"></i>

                    <h6 class="mt-3">

                        Potential Revenue

                    </h6>

                    <h3>

                        KSh <?= number_format($product['quantity'] * $product['selling_price'], 2) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-0 shadow-sm text-center">

                <div class="card-body">

                    <i class="bi bi-currency-dollar display-6 text-warning"></i>

                    <h6 class="mt-3">

                        Potential Profit

                    </h6>

                    <h3>

                        KSh <?= number_format($product['quantity'] * $profit, 2) ?>

                    </h3>

                </div>

            </div>

        </div>

    </div>