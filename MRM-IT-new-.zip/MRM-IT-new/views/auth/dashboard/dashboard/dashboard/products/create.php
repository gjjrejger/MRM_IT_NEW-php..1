<?php

/**
 * ==========================================================
 * MRM Inventory Management System
 * Create Product
 * File: dashboard/products/create.php
 * ==========================================================
 */

require_once '../../app/config/bootstrap.php';

requireLogin();

requirePermission('products.create');

$productController = new ProductController();

/*
|--------------------------------------------------------------------------
| Future Models
|--------------------------------------------------------------------------
|
| These will be replaced with live data once their modules
| are developed.
|
*/

$categories = [];

$suppliers = [];

/*
|--------------------------------------------------------------------------
| Generate Product Code
|--------------------------------------------------------------------------
*/

$productCode = $productController->generateCode();

/*
|--------------------------------------------------------------------------
| Save Product
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($productController->store()) {

        header('Location: index.php');

        exit;

    }

}

$pageTitle = 'Add Product';

include '../partials/header.php';

include '../partials/sidebar.php';

include '../partials/navbar.php';

?>

<div class="container-fluid py-4">

    <!-- ======================================================
         PAGE HEADER
    ======================================================= -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                Add New Product

            </h2>

            <p class="text-muted">

                Create a new inventory product.

            </p>

        </div>

        <a href="index.php"

           class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Back to Products

        </a>

    </div>

    <!-- ======================================================
         ALERTS
    ======================================================= -->

    <?php if (!empty($_SESSION['error'])): ?>

        <div class="alert alert-danger">

            <?= htmlspecialchars($_SESSION['error']) ?>

        </div>

        <?php unset($_SESSION['error']); ?>

    <?php endif; ?>

    <?php if (!empty($_SESSION['success'])): ?>

        <div class="alert alert-success">

            <?= htmlspecialchars($_SESSION['success']) ?>

        </div>

        <?php unset($_SESSION['success']); ?>

    <?php endif; ?>

    <!-- ======================================================
         PRODUCT FORM
    ======================================================= -->

    <form

        action=""

        method="POST"

        enctype="multipart/form-data"

        class="card shadow-sm border-0">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">

                Product Information

            </h5>

        </div>

        <div class="card-body">

            <div class="row">

                <!-- Product Code -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Product Code

                    </label>

                    <input

                        type="text"

                        name="product_code"

                        class="form-control"

                        value="<?= htmlspecialchars($productCode) ?>"

                        readonly>

                </div>

                <!-- Product Name -->

                <div class="col-md-8 mb-3">

                    <label class="form-label">

                        Product Name

                    </label>

                    <input

                        type="text"

                        name="product_name"

                        class="form-control"

                        required>

                </div>
                                <!-- Category -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Category

                    </label>

                    <select
                        name="category_id"
                        class="form-select"
                        required>

                        <option value="">

                            -- Select Category --

                        </option>

                        <?php if (!empty($categories)): ?>

                            <?php foreach ($categories as $category): ?>

                                <option
                                    value="<?= (int)$category['category_id'] ?>">

                                    <?= htmlspecialchars($category['category_name']) ?>

                                </option>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <option disabled>

                                No categories available

                            </option>

                        <?php endif; ?>

                    </select>

                </div>

                <!-- Supplier -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Supplier

                    </label>

                    <select
                        name="supplier_id"
                        class="form-select"
                        required>

                        <option value="">

                            -- Select Supplier --

                        </option>

                        <?php if (!empty($suppliers)): ?>

                            <?php foreach ($suppliers as $supplier): ?>

                                <option
                                    value="<?= (int)$supplier['supplier_id'] ?>">

                                    <?= htmlspecialchars($supplier['supplier_name']) ?>

                                </option>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <option disabled>

                                No suppliers available

                            </option>

                        <?php endif; ?>

                    </select>

                </div>

                <!-- Status -->

                <div class="col-md-4 mb-3">

                    <label class="form-label">

                        Status

                    </label>

                    <select
                        name="status"
                        class="form-select">

                        <option value="Active">

                            Active

                        </option>

                        <option value="Inactive">

                            Inactive

                        </option>

                    </select>

                </div>

                <!-- Quantity -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Opening Quantity

                    </label>

                    <input
                        type="number"
                        name="quantity"
                        class="form-control"
                        min="0"
                        value="0"
                        required>

                </div>

                <!-- Cost Price -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Cost Price (KSh)

                    </label>

                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        name="cost_price"
                        class="form-control"
                        required>

                </div>

                <!-- Selling Price -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Selling Price (KSh)

                    </label>

                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        name="selling_price"
                        class="form-control"
                        required>

                </div>

                <!-- Reorder Level -->

                <div class="col-md-3 mb-3">

                    <label class="form-label">

                        Reorder Level

                    </label>

                    <input
                        type="number"
                        min="0"
                        name="reorder_level"
                        class="form-control"
                        value="10"
                        required>

                </div>

                <!-- Description -->

                <div class="col-12 mb-3">

                    <label class="form-label">

                        Product Description

                    </label>

                    <textarea
                        name="description"
                        rows="5"
                        class="form-control"
                        placeholder="Enter a detailed product description..."></textarea>

                </div>

                <!-- Product Image -->

                <div class="col-md-6 mb-3">

                    <label class="form-label">

                        Product Image

                    </label>

                    <input
                        type="file"
                        name="product_image"
                        class="form-control"
                        accept=".jpg,.jpeg,.png,.webp">

                    <small class="text-muted">

                        Supported formats: JPG, PNG, WEBP (Max 2MB)

                    </small>

                </div>

                <!-- Barcode -->

                <div class="col-md-6 mb-3">

                    <label class="form-label">

                        Barcode

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        value="<?= htmlspecialchars($productCode) ?>"
                        readonly>

                    <small class="text-muted">

                        Barcode will be generated automatically after saving the product.

                    </small>

                </div>

            </div>

        </div>
                <!-- ================================================
             FORM ACTIONS
        ================================================= -->

        <div class="card-footer bg-light">

            <div class="d-flex justify-content-between">

                <a href="index.php"
                   class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>

                    Back

                </a>

                <div>

                    <button
                        type="reset"
                        class="btn btn-warning">

                        <i class="bi bi-arrow-counterclockwise"></i>

                        Reset

                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary">

                        <i class="bi bi-check-circle"></i>

                        Save Product

                    </button>

                </div>

            </div>

        </div>

    </form>

</div>

<?php include '../partials/footer.php'; ?>

<script>

document.addEventListener('DOMContentLoaded', function(){

    const costPrice = document.querySelector('input[name="cost_price"]');

    const sellingPrice = document.querySelector('input[name="selling_price"]');

    const imageInput = document.querySelector('input[name="product_image"]');

    /*
    ==========================================================
    Live Profit Margin
    ==========================================================
    */

    function calculateMargin(){

        if(!costPrice || !sellingPrice){

            return;

        }

        const cost = parseFloat(costPrice.value) || 0;

        const sell = parseFloat(sellingPrice.value) || 0;

        if(cost > 0 && sell > 0){

            const margin = ((sell - cost) / cost) * 100;

            let badge = document.getElementById('marginPreview');

            if(!badge){

                badge = document.createElement('div');

                badge.id = 'marginPreview';

                badge.className = 'alert alert-info mt-2';

                sellingPrice.parentNode.appendChild(badge);

            }

            badge.innerHTML =
                '<strong>Estimated Profit Margin:</strong> '
                + margin.toFixed(2)
                + '%';

        }

    }

    if(costPrice){

        costPrice.addEventListener('input', calculateMargin);

    }

    if(sellingPrice){

        sellingPrice.addEventListener('input', calculateMargin);

    }

    /*
    ==========================================================
    Image Preview
    ==========================================================
    */

    if(imageInput){

        imageInput.addEventListener('change', function(){

            if(!this.files.length){

                return;

            }

            const file = this.files[0];

            if(file.size > 2 * 1024 * 1024){

                alert('Image exceeds 2 MB.');

                this.value = '';

                return;

            }

            let preview = document.getElementById('imagePreview');

            if(!preview){

                preview = document.createElement('img');

                preview.id = 'imagePreview';

                preview.className = 'img-thumbnail mt-3';

                preview.style.maxWidth = '220px';

                imageInput.parentNode.appendChild(preview);

            }

            preview.src = URL.createObjectURL(file);

        });

    }

    /*
    ==========================================================
    Selling Price Validation
    ==========================================================
    */

    const form = document.querySelector('form');

    if(form){

        form.addEventListener('submit', function(e){

            const cost = parseFloat(costPrice.value) || 0;

            const selling = parseFloat(sellingPrice.value) || 0;

            if(selling < cost){

                if(!confirm(
                    'Selling price is lower than the cost price.\n\nContinue anyway?'
                )){

                    e.preventDefault();

                }

            }

        });

    }

});

</script>