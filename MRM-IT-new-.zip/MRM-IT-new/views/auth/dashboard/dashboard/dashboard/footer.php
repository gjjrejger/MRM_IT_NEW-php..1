<?php

/**
 * ==========================================================
 * MRM Inventory Management System (MRM-IT-New)
 * Dashboard Footer
 * File: dashboard/partials/footer.php
 * ==========================================================
 */

?>

        </main>

        <!-- ==========================================================
             FOOTER
        =========================================================== -->

        <footer class="dashboard-footer">

            <div class="container-fluid">

                <div class="row align-items-center">

                    <!-- Left -->

                    <div class="col-md-6">

                        <small>

                            &copy;

                            <?= date('Y'); ?>

                            <strong><?= APP_NAME; ?></strong>

                            |

                            <?= COMPANY_NAME; ?>

                        </small>

                    </div>

                    <!-- Right -->

                    <div class="col-md-6 text-md-end">

                        <small>

                            Version

                            <strong><?= APP_VERSION; ?></strong>

                        </small>

                    </div>

                </div>

            </div>

        </footer>

    </div>

</div>

<!-- ==========================================================
     Bootstrap JS
=========================================================== -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>

<!-- ==========================================================
     Dashboard JavaScript
=========================================================== -->

<script src="<?= APP_URL ?>/dashboard/assets/js/dashboard.js"></script>

<!-- ==========================================================
     Footer Scripts
=========================================================== -->

<script>

document.addEventListener('DOMContentLoaded', function () {

    /*
    |--------------------------------------------------------------------------
    | Current Year
    |--------------------------------------------------------------------------
    */

    const yearElements = document.querySelectorAll('.current-year');

    yearElements.forEach(function(el){

        el.textContent = new Date().getFullYear();

    });

    /*
    |--------------------------------------------------------------------------
    | Page Load Timer
    |--------------------------------------------------------------------------
    */

    const loadTime = performance.now().toFixed(0);

    console.log("MRM Dashboard loaded in " + loadTime + " ms");

});

</script>

<?php if (APP_ENV === 'development'): ?>

<!-- ==========================================================
     Development Information
=========================================================== -->

<div class="text-center py-2 bg-light border-top">

    <small class="text-muted">

        Environment:

        <strong><?= APP_ENV; ?></strong>

        |

        PHP <?= PHP_VERSION; ?>

        |

        Server Time:

        <?= date('d M Y H:i:s'); ?>

    </small>

</div>

<?php endif; ?>

</body>

</html>