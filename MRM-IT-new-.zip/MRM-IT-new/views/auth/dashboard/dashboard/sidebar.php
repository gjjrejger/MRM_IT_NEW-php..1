<?php
/**
 * ==========================================================
 * MRM Inventory Management System (MRM-IT-New)
 * Dashboard Sidebar
 * Part 1
 * ==========================================================
 */

$currentPage = basename($_SERVER['PHP_SELF']);

$role = $_SESSION['role_name'] ?? '';

function menuActive(array $pages): string
{
    global $currentPage;

    return in_array($currentPage, $pages) ? 'active' : '';
}
?>

<!-- ==========================================================
     SIDEBAR
=========================================================== -->

<aside class="sidebar">

    <!-- Logo -->

    <div class="sidebar-header">

        <a href="<?= APP_URL ?>/dashboard/dashboard.php"
           class="logo">

            <div class="logo-icon">

                <i class="bi bi-building-fill"></i>

            </div>

            <div>

                <h5 class="mb-0"><?= APP_SHORT_NAME ?></h5>

                <small>Inventory System</small>

            </div>

        </a>

    </div>

    <!-- Logged-in User -->

    <div class="user-panel">

        <div class="avatar">

            <?= strtoupper(substr($_SESSION['first_name'],0,1)); ?>

        </div>

        <div class="user-info">

            <strong>

                <?= htmlspecialchars($_SESSION['full_name']); ?>

            </strong>

            <br>

            <small>

                <?= htmlspecialchars($_SESSION['role_name']); ?>

            </small>

        </div>

    </div>

    <!-- Navigation -->

    <nav class="sidebar-menu">

        <ul>

            <!-- Dashboard -->

            <li class="<?= menuActive(['dashboard.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/dashboard.php">

                    <i class="bi bi-speedometer2"></i>

                    Dashboard

                </a>

            </li>

            <!-- =====================================================
                 USER MANAGEMENT
            ====================================================== -->

            <?php if(
                $role === ROLE_SUPER_ADMIN
                || $role === ROLE_FINANCE_ADMIN
            ): ?>

            <li class="menu-header">

                Administration

            </li>

            <li class="<?= menuActive(['users.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/users/users.php">

                    <i class="bi bi-people-fill"></i>

                    Users

                </a>

            </li>

            <li class="<?= menuActive(['roles.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/users/roles.php">

                    <i class="bi bi-person-badge-fill"></i>

                    Roles

                </a>

            </li>

            <li class="<?= menuActive(['permissions.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/users/permissions.php">

                    <i class="bi bi-shield-lock-fill"></i>

                    Permissions

                </a>

            </li>

            <?php endif; ?>

            <!-- Divider -->

            <li class="menu-header">

                Inventory Management

            </li>
                        <!-- =====================================================
                 INVENTORY MANAGEMENT
            ====================================================== -->

            <?php if (
                in_array($role, [
                    ROLE_SUPER_ADMIN,
                    ROLE_INVENTORY_ADMIN
                ])
            ): ?>

            <li class="<?= menuActive(['products.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/products/products.php">

                    <i class="bi bi-box-seam"></i>

                    Products

                </a>

            </li>

            <li class="<?= menuActive(['categories.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/categories/categories.php">

                    <i class="bi bi-tags-fill"></i>

                    Categories

                </a>

            </li>

            <li class="<?= menuActive(['warehouses.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/warehouses/warehouses.php">

                    <i class="bi bi-building"></i>

                    Warehouses

                </a>

            </li>

            <li class="<?= menuActive(['inventory.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/inventory/inventory.php">

                    <i class="bi bi-boxes"></i>

                    Inventory

                </a>

            </li>

            <li class="<?= menuActive(['stock_in.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/inventory/stock_in.php">

                    <i class="bi bi-box-arrow-in-down"></i>

                    Stock In

                </a>

            </li>

            <li class="<?= menuActive(['stock_out.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/inventory/stock_out.php">

                    <i class="bi bi-box-arrow-up"></i>

                    Stock Out

                </a>

            </li>

            <li class="<?= menuActive(['stock_adjustments.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/inventory/stock_adjustments.php">

                    <i class="bi bi-sliders"></i>

                    Stock Adjustments

                </a>

            </li>

            <?php endif; ?>


            <!-- =====================================================
                 PROCUREMENT
            ====================================================== -->

            <?php if (
                in_array($role, [
                    ROLE_SUPER_ADMIN,
                    ROLE_INVENTORY_ADMIN,
                    ROLE_LOGISTICS_ADMIN
                ])
            ): ?>

            <li class="menu-header">

                Procurement

            </li>

            <li class="<?= menuActive(['suppliers.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/suppliers/suppliers.php">

                    <i class="bi bi-truck"></i>

                    Suppliers

                </a>

            </li>

            <li class="<?= menuActive(['purchase_orders.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/purchases/purchase_orders.php">

                    <i class="bi bi-cart-check-fill"></i>

                    Purchase Orders

                </a>

            </li>

            <li class="<?= menuActive(['goods_received.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/purchases/goods_received.php">

                    <i class="bi bi-box-arrow-in-right"></i>

                    Goods Received

                </a>

            </li>

            <?php endif; ?>


            <!-- =====================================================
                 SALES
            ====================================================== -->

            <?php if (
                in_array($role, [
                    ROLE_SUPER_ADMIN,
                    ROLE_SALES_ADMIN,
                    ROLE_FINANCE_ADMIN
                ])
            ): ?>

            <li class="menu-header">

                Sales

            </li>

            <li class="<?= menuActive(['customers.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/customers/customers.php">

                    <i class="bi bi-people"></i>

                    Customers

                </a>

            </li>

            <li class="<?= menuActive(['sales_orders.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/sales/sales_orders.php">

                    <i class="bi bi-receipt"></i>

                    Sales Orders

                </a>

            </li>

            <li class="<?= menuActive(['invoices.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/sales/invoices.php">

                    <i class="bi bi-file-earmark-text"></i>

                    Invoices

                </a>

            </li>

            <li class="<?= menuActive(['payments.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/sales/payments.php">

                    <i class="bi bi-cash-stack"></i>

                    Payments

                </a>

            </li>

            <?php endif; ?>


            <!-- =====================================================
                 LOGISTICS
            ====================================================== -->

            <?php if (
                in_array($role, [
                    ROLE_SUPER_ADMIN,
                    ROLE_LOGISTICS_ADMIN
                ])
            ): ?>

            <li class="menu-header">

                Logistics

            </li>

            <li class="<?= menuActive(['dispatch.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/logistics/dispatch.php">

                    <i class="bi bi-truck-flatbed"></i>

                    Dispatch

                </a>

            </li>

            <li class="<?= menuActive(['deliveries.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/logistics/deliveries.php">

                    <i class="bi bi-geo-alt-fill"></i>

                    Deliveries

                </a>

            </li>

            <li class="<?= menuActive(['returns.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/logistics/returns.php">

                    <i class="bi bi-arrow-return-left"></i>

                    Returns

                </a>

            </li>

            <?php endif; ?>
            <!-- =====================================================
                 REPORTS
            ====================================================== -->

            <li class="menu-header">

                Reports & Monitoring

            </li>

            <li class="<?= menuActive(['reports.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/reports/reports.php">

                    <i class="bi bi-bar-chart-line-fill"></i>

                    Reports

                </a>

            </li>

            <?php if (
                in_array($role, [
                    ROLE_SUPER_ADMIN,
                    ROLE_FINANCE_ADMIN,
                    ROLE_INVENTORY_ADMIN
                ])
            ): ?>

            <li class="<?= menuActive(['approvals.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/approvals/approvals.php">

                    <i class="bi bi-check2-square"></i>

                    Pending Approvals

                </a>

            </li>

            <?php endif; ?>

            <?php if ($role === ROLE_SUPER_ADMIN): ?>

            <li class="<?= menuActive(['audit_logs.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/system/audit_logs.php">

                    <i class="bi bi-journal-text"></i>

                    Audit Logs

                </a>

            </li>

            <li class="<?= menuActive(['system_settings.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/system/system_settings.php">

                    <i class="bi bi-gear-fill"></i>

                    System Settings

                </a>

            </li>

            <?php endif; ?>

            <!-- =====================================================
                 ACCOUNT
            ====================================================== -->

            <li class="menu-header">

                Account

            </li>

            <li class="<?= menuActive(['profile.php']); ?>">

                <a href="<?= APP_URL ?>/dashboard/profile.php">

                    <i class="bi bi-person-circle"></i>

                    My Profile

                </a>

            </li>

            <li>

                <a href="<?= APP_URL ?>/public/logout.php"
                   onclick="return confirm('Are you sure you want to logout?');">

                    <i class="bi bi-box-arrow-right"></i>

                    Logout

                </a>

            </li>

        </ul>

    </nav>

</aside>