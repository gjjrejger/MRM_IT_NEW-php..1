/**
 * ==========================================================
 * MRM Inventory Management System (MRM-IT-New)
 * Dashboard JavaScript
 * File: dashboard/assets/js/dashboard.js
 * ==========================================================
 */

'use strict';

/*
|--------------------------------------------------------------------------
| Dashboard Object
|--------------------------------------------------------------------------
*/

const Dashboard = {

    init() {

        this.sidebar();

        this.clock();

        this.tooltips();

        this.confirmActions();

        this.autoHideAlerts();

        this.search();

        this.notifications();

        console.log('MRM Dashboard Initialized');

    },

    /*
    |--------------------------------------------------------------------------
    | Sidebar
    |--------------------------------------------------------------------------
    */

    sidebar() {

        const sidebar = document.querySelector('.sidebar');

        const toggle = document.getElementById('sidebarToggle');

        if (!sidebar || !toggle) return;

        toggle.addEventListener('click', () => {

            sidebar.classList.toggle('show');

        });

    },

    /*
    |--------------------------------------------------------------------------
    | Live Clock
    |--------------------------------------------------------------------------
    */

    clock() {

        const clock = document.getElementById('currentDateTime');

        if (!clock) return;

        function updateClock() {

            const now = new Date();

            clock.textContent = now.toLocaleString();

        }

        updateClock();

        setInterval(updateClock, 1000);

    },

    /*
    |--------------------------------------------------------------------------
    | Bootstrap Tooltips
    |--------------------------------------------------------------------------
    */

    tooltips() {

        const tooltipTriggerList = [].slice.call(

            document.querySelectorAll('[data-bs-toggle="tooltip"]')

        );

        tooltipTriggerList.map(function (el) {

            return new bootstrap.Tooltip(el);

        });

    },

    /*
    |--------------------------------------------------------------------------
    | Confirm Delete / Logout Buttons
    |--------------------------------------------------------------------------
    */

    confirmActions() {

        document.querySelectorAll('[data-confirm]').forEach(button => {

            button.addEventListener('click', function (e) {

                const message = this.dataset.confirm;

                if (!confirm(message)) {

                    e.preventDefault();

                }

            });

        });

    },

    /*
    |--------------------------------------------------------------------------
    | Auto-hide Alerts
    |--------------------------------------------------------------------------
    */

    autoHideAlerts() {

        const alerts = document.querySelectorAll('.alert');

        alerts.forEach(alert => {

            setTimeout(() => {

                alert.classList.add('fade');

                setTimeout(() => {

                    alert.remove();

                }, 500);

            }, 5000);

        });

    },

    /*
    |--------------------------------------------------------------------------
    | Search
    |--------------------------------------------------------------------------
    */

    search() {

        const input = document.querySelector('#globalSearch');

        if (!input) return;

        input.addEventListener('keyup', function () {

            console.log('Searching:', this.value);

            // AJAX implementation will be added later.

        });

    },

    /*
    |--------------------------------------------------------------------------
    | Notifications
    |--------------------------------------------------------------------------
    */

    notifications() {

        console.log('Notifications module ready.');

    }

};

/*
|--------------------------------------------------------------------------
| Initialize Dashboard
|--------------------------------------------------------------------------
*/

document.addEventListener('DOMContentLoaded', () => {

    Dashboard.init();

});
/*
|--------------------------------------------------------------------------
| Dashboard Statistics Animation
|--------------------------------------------------------------------------
*/

Dashboard.animateCounters = function () {

    const counters = document.querySelectorAll('[data-counter]');

    counters.forEach(counter => {

        const target = parseInt(counter.dataset.counter) || 0;

        let current = 0;

        const increment = Math.max(1, Math.ceil(target / 100));

        const timer = setInterval(() => {

            current += increment;

            if (current >= target) {

                current = target;

                clearInterval(timer);

            }

            counter.textContent = current.toLocaleString();

        }, 20);

    });

};

/*
|--------------------------------------------------------------------------
| Bootstrap Toast Notifications
|--------------------------------------------------------------------------
*/

Dashboard.showToast = function (title, message, type = 'primary') {

    const toastContainer = document.getElementById('toastContainer');

    if (!toastContainer) return;

    const id = 'toast-' + Date.now();

    const toast = document.createElement('div');

    toast.className = `toast text-bg-${type}`;

    toast.id = id;

    toast.setAttribute('role', 'alert');

    toast.innerHTML = `

        <div class="toast-header">

            <strong class="me-auto">${title}</strong>

            <small>Now</small>

            <button type="button"
                class="btn-close"
                data-bs-dismiss="toast"></button>

        </div>

        <div class="toast-body">

            ${message}

        </div>

    `;

    toastContainer.appendChild(toast);

    const bsToast = new bootstrap.Toast(toast);

    bsToast.show();

    toast.addEventListener('hidden.bs.toast', () => {

        toast.remove();

    });

};

/*
|--------------------------------------------------------------------------
| Low Stock Alerts
|--------------------------------------------------------------------------
*/

Dashboard.checkLowStock = function () {

    const rows = document.querySelectorAll('[data-stock]');

    rows.forEach(row => {

        const stock = parseInt(row.dataset.stock);

        const reorder = parseInt(row.dataset.reorder);

        if (stock <= reorder) {

            row.classList.add('table-warning');

        }

    });

};

/*
|--------------------------------------------------------------------------
| Dashboard Auto Refresh
|--------------------------------------------------------------------------
*/

Dashboard.autoRefresh = function () {

    const widgets = document.querySelectorAll('[data-refresh]');

    if (!widgets.length) return;

    setInterval(() => {

        console.log('Refreshing dashboard widgets...');

        // AJAX refresh will be implemented later.

    }, 60000);

};

/*
|--------------------------------------------------------------------------
| Table Search Filter
|--------------------------------------------------------------------------
*/

Dashboard.tableSearch = function () {

    const input = document.getElementById('tableSearch');

    if (!input) return;

    input.addEventListener('keyup', function () {

        const value = this.value.toLowerCase();

        document.querySelectorAll('tbody tr').forEach(row => {

            row.style.display = row.innerText.toLowerCase().includes(value)

                ? ''

                : 'none';

        });

    });

};

/*
|--------------------------------------------------------------------------
| Scroll To Top
|--------------------------------------------------------------------------
*/

Dashboard.scrollTopButton = function () {

    const button = document.getElementById('scrollTop');

    if (!button) return;

    window.addEventListener('scroll', () => {

        button.style.display = window.scrollY > 250

            ? 'block'

            : 'none';

    });

    button.addEventListener('click', () => {

        window.scrollTo({

            top: 0,

            behavior: 'smooth'

        });

    });

};

/*
|--------------------------------------------------------------------------
| Loading Spinner
|--------------------------------------------------------------------------
*/

Dashboard.showLoader = function () {

    const loader = document.getElementById('pageLoader');

    if (loader) {

        loader.style.display = 'flex';

    }

};

Dashboard.hideLoader = function () {

    const loader = document.getElementById('pageLoader');

    if (loader) {

        loader.style.display = 'none';

    }

};

/*
|--------------------------------------------------------------------------
| Mobile Sidebar Auto Close
|--------------------------------------------------------------------------
*/

Dashboard.mobileSidebar = function () {

    if (window.innerWidth > 992) return;

    document.querySelectorAll('.sidebar a').forEach(link => {

        link.addEventListener('click', () => {

            document.querySelector('.sidebar')

                ?.classList.remove('show');

        });

    });

};

/*
|--------------------------------------------------------------------------
| Initialize Part 2 Modules
|--------------------------------------------------------------------------
*/

document.addEventListener('DOMContentLoaded', () => {

    Dashboard.animateCounters();

    Dashboard.checkLowStock();

    Dashboard.autoRefresh();

    Dashboard.tableSearch();

    Dashboard.scrollTopButton();

    Dashboard.mobileSidebar();

});
/*
|--------------------------------------------------------------------------
| AJAX Helper
|--------------------------------------------------------------------------
*/

Dashboard.ajax = async function (url, options = {}) {

    Dashboard.showLoader();

    try {

        const response = await fetch(url, {

            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'application/json',
                ...(options.headers || {})
            },

            ...options

        });

        Dashboard.hideLoader();

        return await response.json();

    } catch (error) {

        Dashboard.hideLoader();

        console.error(error);

        Dashboard.showToast(
            'Error',
            'Unable to communicate with the server.',
            'danger'
        );

        throw error;

    }

};

/*
|--------------------------------------------------------------------------
| Form Validation
|--------------------------------------------------------------------------
*/

Dashboard.validateRequired = function (form) {

    let valid = true;

    form.querySelectorAll('[required]').forEach(field => {

        field.classList.remove('is-invalid');

        if (field.value.trim() === '') {

            field.classList.add('is-invalid');

            valid = false;

        }

    });

    return valid;

};

/*
|--------------------------------------------------------------------------
| Auto Form Validation
|--------------------------------------------------------------------------
*/

Dashboard.forms = function () {

    document.querySelectorAll('form').forEach(form => {

        form.addEventListener('submit', function (e) {

            if (!Dashboard.validateRequired(form)) {

                e.preventDefault();

                Dashboard.showToast(
                    'Validation',
                    'Please complete all required fields.',
                    'warning'
                );

            }

        });

    });

};

/*
|--------------------------------------------------------------------------
| CSRF Token
|--------------------------------------------------------------------------
*/

Dashboard.csrf = function () {

    const meta = document.querySelector(
        'meta[name="csrf-token"]'
    );

    return meta ? meta.content : '';

};

/*
|--------------------------------------------------------------------------
| Modal Helper
|--------------------------------------------------------------------------
*/

Dashboard.openModal = function (id) {

    const modal = document.getElementById(id);

    if (!modal) return;

    new bootstrap.Modal(modal).show();

};

/*
|--------------------------------------------------------------------------
| Close Modal
|--------------------------------------------------------------------------
*/

Dashboard.closeModal = function (id) {

    const modal = document.getElementById(id);

    if (!modal) return;

    const instance = bootstrap.Modal.getInstance(modal);

    if (instance) {

        instance.hide();

    }

};

/*
|--------------------------------------------------------------------------
| Chart.js Placeholder
|--------------------------------------------------------------------------
*/

Dashboard.loadCharts = function () {

    console.log('Charts module ready.');

    /*
        Future:
        Sales Chart
        Stock Movement
        Purchase Trends
        Revenue Analysis
    */

};

/*
|--------------------------------------------------------------------------
| Approval Workflow
|--------------------------------------------------------------------------
*/

Dashboard.approve = function (id) {

    console.log('Approve Request:', id);

};

Dashboard.reject = function (id) {

    console.log('Reject Request:', id);

};

/*
|--------------------------------------------------------------------------
| Generic Delete Helper
|--------------------------------------------------------------------------
*/

Dashboard.deleteRecord = function (url) {

    if (!confirm('Delete this record?')) {

        return;

    }

    window.location.href = url;

};

/*
|--------------------------------------------------------------------------
| Copy To Clipboard
|--------------------------------------------------------------------------
*/

Dashboard.copy = function (text) {

    navigator.clipboard.writeText(text);

    Dashboard.showToast(

        'Copied',

        'Copied to clipboard.',

        'success'

    );

};

/*
|--------------------------------------------------------------------------
| Number Formatter
|--------------------------------------------------------------------------
*/

Dashboard.number = function (number) {

    return new Intl.NumberFormat().format(number);

};

/*
|--------------------------------------------------------------------------
| Currency Formatter
|--------------------------------------------------------------------------
*/

Dashboard.money = function (amount) {

    return new Intl.NumberFormat(

        'en-KE',

        {

            style: 'currency',

            currency: 'KES'

        }

    ).format(amount);

};

/*
|--------------------------------------------------------------------------
| Date Formatter
|--------------------------------------------------------------------------
*/

Dashboard.date = function (date) {

    return new Date(date)

        .toLocaleDateString();

};

/*
|--------------------------------------------------------------------------
| Central Error Handler
|--------------------------------------------------------------------------
*/

window.addEventListener('error', function (e) {

    console.error('Application Error:', e.message);

});

/*
|--------------------------------------------------------------------------
| Initialize Part 3
|--------------------------------------------------------------------------
*/

document.addEventListener('DOMContentLoaded', function () {

    Dashboard.forms();

    Dashboard.loadCharts();

    Dashboard.hideLoader();

    console.log('MRM ERP Dashboard Ready');

});