<?php

/**
 * ==========================================================
 * MRM Inventory Management System (MRM-IT-New)
 * Navigation Menu Configuration
 * File: app/config/menu.php
 * ==========================================================
 */

declare(strict_types=1);

return [

    /*
    |--------------------------------------------------------------------------
    | Main Navigation
    |--------------------------------------------------------------------------
    */

    'main' => [

        [
            'title' => 'Dashboard',
            'icon'  => 'bi-speedometer2',
            'url'   => APP_URL . '/dashboard/dashboard.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_FINANCE_ADMIN,
                ROLE_INVENTORY_ADMIN,
                ROLE_SALES_ADMIN,
                ROLE_LOGISTICS_ADMIN
            ]
        ]

    ],

    /*
    |--------------------------------------------------------------------------
    | Administration
    |--------------------------------------------------------------------------
    */

    'Administration' => [

        [
            'title' => 'Users',
            'icon'  => 'bi-people-fill',
            'url'   => APP_URL . '/dashboard/users/users.php',
            'roles' => [
                ROLE_SUPER_ADMIN
            ]
        ],

        [
            'title' => 'Roles',
            'icon'  => 'bi-person-badge-fill',
            'url'   => APP_URL . '/dashboard/users/roles.php',
            'roles' => [
                ROLE_SUPER_ADMIN
            ]
        ],

        [
            'title' => 'Permissions',
            'icon'  => 'bi-shield-lock-fill',
            'url'   => APP_URL . '/dashboard/users/permissions.php',
            'roles' => [
                ROLE_SUPER_ADMIN
            ]
        ]

    ],

    /*
    |--------------------------------------------------------------------------
    | Inventory
    |--------------------------------------------------------------------------
    */

    'Inventory' => [

        [
            'title' => 'Products',
            'icon'  => 'bi-box-seam',
            'url'   => APP_URL . '/dashboard/products/products.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Categories',
            'icon'  => 'bi-tags-fill',
            'url'   => APP_URL . '/dashboard/categories/categories.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Warehouses',
            'icon'  => 'bi-building',
            'url'   => APP_URL . '/dashboard/warehouses/warehouses.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Inventory',
            'icon'  => 'bi-boxes',
            'url'   => APP_URL . '/dashboard/inventory/inventory.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Stock In',
            'icon'  => 'bi-box-arrow-in-down',
            'url'   => APP_URL . '/dashboard/inventory/stock_in.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Stock Out',
            'icon'  => 'bi-box-arrow-up',
            'url'   => APP_URL . '/dashboard/inventory/stock_out.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Stock Adjustments',
            'icon'  => 'bi-sliders',
            'url'   => APP_URL . '/dashboard/inventory/stock_adjustments.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ]

    ],

    /*
    |--------------------------------------------------------------------------
    | Procurement
    |--------------------------------------------------------------------------
    */

    'Procurement' => [

        [
            'title' => 'Suppliers',
            'icon'  => 'bi-truck',
            'url'   => APP_URL . '/dashboard/suppliers/suppliers.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_LOGISTICS_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Purchase Orders',
            'icon'  => 'bi-cart-check-fill',
            'url'   => APP_URL . '/dashboard/purchases/purchase_orders.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_LOGISTICS_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Goods Received',
            'icon'  => 'bi-box-arrow-in-right',
            'url'   => APP_URL . '/dashboard/purchases/goods_received.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_LOGISTICS_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ]

    ],

    /*
    |--------------------------------------------------------------------------
    | Sales
    |--------------------------------------------------------------------------
    */

    'Sales' => [

        [
            'title' => 'Customers',
            'icon'  => 'bi-people',
            'url'   => APP_URL . '/dashboard/customers/customers.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_SALES_ADMIN,
                ROLE_FINANCE_ADMIN
            ]
        ],

        [
            'title' => 'Sales Orders',
            'icon'  => 'bi-receipt',
            'url'   => APP_URL . '/dashboard/sales/sales_orders.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_SALES_ADMIN
            ]
        ],

        [
            'title' => 'Invoices',
            'icon'  => 'bi-file-earmark-text',
            'url'   => APP_URL . '/dashboard/sales/invoices.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_FINANCE_ADMIN
            ]
        ],

        [
            'title' => 'Payments',
            'icon'  => 'bi-cash-stack',
            'url'   => APP_URL . '/dashboard/sales/payments.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_FINANCE_ADMIN
            ]
        ]

    ],

    /*
    |--------------------------------------------------------------------------
    | Logistics
    |--------------------------------------------------------------------------
    */

    'Logistics' => [

        [
            'title' => 'Dispatch',
            'icon'  => 'bi-truck-flatbed',
            'url'   => APP_URL . '/dashboard/logistics/dispatch.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_LOGISTICS_ADMIN
            ]
        ],

        [
            'title' => 'Deliveries',
            'icon'  => 'bi-geo-alt-fill',
            'url'   => APP_URL . '/dashboard/logistics/deliveries.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_LOGISTICS_ADMIN
            ]
        ],

        [
            'title' => 'Returns',
            'icon'  => 'bi-arrow-return-left',
            'url'   => APP_URL . '/dashboard/logistics/returns.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_LOGISTICS_ADMIN
            ]
        ]

    ],

    /*
    |--------------------------------------------------------------------------
    | Reports & Monitoring
    |--------------------------------------------------------------------------
    */

    'Reports & Monitoring' => [

        [
            'title' => 'Reports',
            'icon'  => 'bi-bar-chart-line-fill',
            'url'   => APP_URL . '/dashboard/reports/reports.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_FINANCE_ADMIN,
                ROLE_INVENTORY_ADMIN,
                ROLE_SALES_ADMIN,
                ROLE_LOGISTICS_ADMIN
            ]
        ],

        [
            'title' => 'Pending Approvals',
            'icon'  => 'bi-check2-square',
            'url'   => APP_URL . '/dashboard/approvals/approvals.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_FINANCE_ADMIN,
                ROLE_INVENTORY_ADMIN
            ]
        ],

        [
            'title' => 'Audit Logs',
            'icon'  => 'bi-journal-text',
            'url'   => APP_URL . '/dashboard/system/audit_logs.php',
            'roles' => [
                ROLE_SUPER_ADMIN
            ]
        ],

        [
            'title' => 'System Settings',
            'icon'  => 'bi-gear-fill',
            'url'   => APP_URL . '/dashboard/system/system_settings.php',
            'roles' => [
                ROLE_SUPER_ADMIN
            ]
        ]

    ],

    /*
    |--------------------------------------------------------------------------
    | Account
    |--------------------------------------------------------------------------
    */

    'Account' => [

        [
            'title' => 'My Profile',
            'icon'  => 'bi-person-circle',
            'url'   => APP_URL . '/dashboard/profile.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_FINANCE_ADMIN,
                ROLE_INVENTORY_ADMIN,
                ROLE_SALES_ADMIN,
                ROLE_LOGISTICS_ADMIN
            ]
        ],

        [
            'title' => 'Logout',
            'icon'  => 'bi-box-arrow-right',
            'url'   => APP_URL . '/public/logout.php',
            'roles' => [
                ROLE_SUPER_ADMIN,
                ROLE_FINANCE_ADMIN,
                ROLE_INVENTORY_ADMIN,
                ROLE_SALES_ADMIN,
                ROLE_LOGISTICS_ADMIN
            ]
        ]

    ]

];
