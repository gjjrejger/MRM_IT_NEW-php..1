<?php

/**
 * ==========================================================
 * MRM Inventory Management System
 * Products Management
 * File: dashboard/products/index.php
 * ==========================================================
 */

require_once '../../app/config/bootstrap.php';

requireLogin();

requirePermission('products.view');

$productController = new ProductController();

$products = $productController->index();

$pageTitle = 'Products Management';

include '../partials/header.php';
include '../partials/sidebar.php';
include '../partials/navbar.php';
?>

<div class="container-fluid py-4">

    <!-- ======================================================
         PAGE HEADER
    ======================================================= -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold mb-1">

                Products Management

            </h2>

            <p class="text-muted mb-0">

                Manage all inventory products.

            </p>

        </div>

        <div>

            <?php if (hasPermission('products.create')): ?>

                <a href="create.php"

                   class="btn btn-primary">

                    <i class="bi bi-plus-circle me-2"></i>

                    Add Product

                </a>

            <?php endif; ?>

        </div>

    </div>

    <!-- ======================================================
         ALERT MESSAGES
    ======================================================= -->

    <?php if (!empty($_SESSION['success'])): ?>

        <div class="alert alert-success alert-dismissible fade show">

            <?= htmlspecialchars($_SESSION['success']) ?>

            <button class="btn-close"

                    data-bs-dismiss="alert"></button>

        </div>

        <?php unset($_SESSION['success']); ?>

    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>

        <div class="alert alert-danger alert-dismissible fade show">

            <?= htmlspecialchars($_SESSION['error']) ?>

            <button class="btn-close"

                    data-bs-dismiss="alert"></button>

        </div>

        <?php unset($_SESSION['error']); ?>

    <?php endif; ?>

    <!-- ======================================================
         TOOLBAR
    ======================================================= -->

    <div class="card shadow-sm border-0 mb-4">

        <div class="card-body">

            <div class="row g-3">

                <div class="col-md-4">

                    <input type="text"

                           id="productSearch"

                           class="form-control"

                           placeholder="Search products...">

                </div>

                <div class="col-md-2">

                    <select class="form-select">

                        <option>All Categories</option>

                    </select>

                </div>

                <div class="col-md-2">

                    <select class="form-select">

                        <option>All Suppliers</option>

                    </select>

                </div>

                <div class="col-md-2">

                    <select class="form-select">

                        <option>All Status</option>

                        <option>Active</option>

                        <option>Inactive</option>

                        <option>Deleted</option>

                    </select>

                </div>

                <div class="col-md-2">

                    <button class="btn btn-outline-secondary w-100">

                        Filter

                    </button>

                </div>

            </div>

        </div>

    </div>

    <!-- ======================================================
         PRODUCTS TABLE
    ======================================================= -->

    <div class="card shadow-sm border-0">

        <div class="card-header bg-white">

            <h5 class="mb-0">

                Product List

            </h5>

        </div>

        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0"

                   id="productsTable">

                <thead class="table-light">

                <tr>

                    <th width="40">

                        <input type="checkbox"

                               id="selectAll">

                    </th>

                    <th>Code</th>

                    <th>Product</th>

                    <th>Category</th>

                    <th>Supplier</th>

                    <th class="text-end">Stock</th>

                    <th class="text-end">Cost</th>

                    <th class="text-end">Selling</th>

                    <th>Status</th>

                    <th width="180">

                        Actions

                    </th>

                </tr>

                </thead>

                <tbody>
                    <?php if (!empty($products)): ?>

    <?php foreach ($products as $product): ?>

        <?php

            $stockClass = '';

            if ($product['quantity'] <= 0) {

                $stockClass = 'table-danger';

            } elseif ($product['quantity'] <= $product['reorder_level']) {

                $stockClass = 'table-warning';

            }

        ?>

        <tr class="<?= $stockClass ?>">

            <!-- Checkbox -->

            <td>

                <input
                    type="checkbox"
                    class="product-check"
                    value="<?= (int)$product['product_id'] ?>">

            </td>

            <!-- Product Code -->

            <td>

                <strong>

                    <?= htmlspecialchars($product['product_code']) ?>

                </strong>

            </td>

            <!-- Product Name -->

            <td>

                <?= htmlspecialchars($product['product_name']) ?>

            </td>

            <!-- Category -->

            <td>

                <?= htmlspecialchars($product['category_name'] ?? 'N/A') ?>

            </td>

            <!-- Supplier -->

            <td>

                <?= htmlspecialchars($product['supplier_name'] ?? 'N/A') ?>

            </td>

            <!-- Quantity -->

            <td class="text-end">

                <?php

                if ($product['quantity'] <= 0):

                ?>

                    <span class="badge bg-danger">

                        <?= number_format($product['quantity']) ?>

                    </span>

                <?php

                elseif ($product['quantity'] <= $product['reorder_level']):

                ?>

                    <span class="badge bg-warning text-dark">

                        <?= number_format($product['quantity']) ?>

                    </span>

                <?php else: ?>

                    <span class="badge bg-success">

                        <?= number_format($product['quantity']) ?>

                    </span>

                <?php endif; ?>

            </td>

            <!-- Cost Price -->

            <td class="text-end">

                <?= number_format((float)$product['cost_price'], 2) ?>

            </td>

            <!-- Selling Price -->

            <td class="text-end">

                <?= number_format((float)$product['selling_price'], 2) ?>

            </td>

            <!-- Status -->

            <td>

                <?php

                switch ($product['status']) {

                    case 'Active':

                        echo '<span class="badge bg-success">Active</span>';

                        break;

                    case 'Inactive':

                        echo '<span class="badge bg-secondary">Inactive</span>';

                        break;

                    case 'Deleted':

                        echo '<span class="badge bg-danger">Deleted</span>';

                        break;

                    default:

                        echo '<span class="badge bg-light text-dark">'
                            . htmlspecialchars($product['status']) .
                            '</span>';

                }

                ?>

            </td>

            <!-- Action Buttons -->

            <td>

                <div class="btn-group btn-group-sm">

                    <?php if (hasPermission('products.view')): ?>

                        <a href="view.php?id=<?= (int)$product['product_id'] ?>"

                           class="btn btn-outline-info"

                           title="View">

                            <i class="bi bi-eye"></i>

                        </a>

                    <?php endif; ?>

                    <?php if (hasPermission('products.edit')): ?>

                        <a href="edit.php?id=<?= (int)$product['product_id'] ?>"

                           class="btn btn-outline-primary"

                           title="Edit">

                            <i class="bi bi-pencil-square"></i>

                        </a>

                    <?php endif; ?>

                    <?php if (hasPermission('products.delete')): ?>

                        <a href="delete.php?id=<?= (int)$product['product_id'] ?>"

                           class="btn btn-outline-danger"

                           onclick="return confirm('Delete this product?')"

                           title="Delete">

                            <i class="bi bi-trash"></i>

                        </a>

                    <?php endif; ?>

                </div>

            </td>

        </tr>

    <?php endforeach; ?>

<?php else: ?>

    <tr>

        <td colspan="10" class="text-center py-5">

            <i class="bi bi-box-seam display-4 text-muted"></i>

            <h5 class="mt-3">

                No products found

            </h5>

            <p class="text-muted">

                Click "Add Product" to create your first product.

            </p>

        </td>

    </tr>

<?php endif; ?>

</tbody>

</table>

</div>

</div>
    <!-- ======================================================
         BULK ACTIONS
    ======================================================= -->

    <div class="card shadow-sm border-0 mt-4">

        <div class="card-body">

            <div class="row align-items-center">

                <div class="col-md-6">

                    <div class="btn-group">

                        <?php if (hasPermission('products.delete')): ?>

                            <button
                                type="button"
                                class="btn btn-outline-danger"
                                id="bulkDelete">

                                <i class="bi bi-trash"></i>

                                Delete Selected

                            </button>

                        <?php endif; ?>

                        <a href="export.php"

                           class="btn btn-outline-success">

                            <i class="bi bi-file-earmark-excel"></i>

                            Export Excel

                        </a>

                        <a href="barcode.php"

                           class="btn btn-outline-dark">

                            <i class="bi bi-upc-scan"></i>

                            Print Barcodes

                        </a>

                    </div>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Total Products:

                        <strong>

                            <?= count($products) ?>

                        </strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include '../partials/footer.php'; ?>

<script>

document.addEventListener('DOMContentLoaded', () => {

    const selectAll = document.getElementById('selectAll');

    const checkboxes = document.querySelectorAll('.product-check');

    if(selectAll){

        selectAll.addEventListener('change', function(){

            checkboxes.forEach(cb => {

                cb.checked = this.checked;

            });

        });

    }

    const searchInput = document.getElementById('productSearch');

    const tableRows = document.querySelectorAll('#productsTable tbody tr');

    if(searchInput){

        searchInput.addEventListener('keyup', function(){

            const keyword = this.value.toLowerCase();

            tableRows.forEach(row=>{

                row.style.display = row.innerText
                    .toLowerCase()
                    .includes(keyword)

                    ? ''

                    : 'none';

            });

        });

    }

    const bulkDelete = document.getElementById('bulkDelete');

    if(bulkDelete){

        bulkDelete.addEventListener('click', function(){

            let selected = [];

            document
                .querySelectorAll('.product-check:checked')
                .forEach(item => {

                    selected.push(item.value);

                });

            if(selected.length===0){

                alert('Please select at least one product.');

                return;

            }

            if(!confirm('Delete selected products?')){

                return;

            }

            console.log(selected);

            /*
             Future AJAX:

             fetch('api.php',{
                 method:'POST',
                 body:...
             });

            */

        });

    }

});

</script>